---
name: kanban
description: "Kanban multi-agent work queue: orchestrator decomposition + worker execution. Use when routing work through Kanban boards, decomposing tasks for multiple profiles, or executing dispatched worker tasks."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
environments: [kanban]
metadata:
  hermes:
    tags: [kanban, multi-agent, orchestration, routing, workflow, collaboration]
    related_skills: [hermes-agent]
---

# Kanban Multi-Agent Work Queue

Hermes Kanban is a durable SQLite board for multi-profile / multi-worker collaboration. Two roles exist: **orchestrators** (decompose and route work) and **workers** (execute dispatched tasks). This skill covers both roles.

## When to Use

- Multiple specialists are needed for a task (research + analysis + writing)
- Work should survive crashes or restarts (durable task queue)
- Multiple subtasks can run in parallel (fan-out)
- Review/iteration is expected between agents
- The audit trail matters (board rows persist in SQLite)

## Quick Decision: Orchestrator vs Worker

| Role | You are... | Your job |
|------|-----------|----------|
| **Orchestrator** | A profile whose whole job is routing | Decompose goals into task graphs, create cards, assign to specialists, summarize results |
| **Worker** | A dispatched agent with a specific card | Orient on the card, do the work, heartbeat progress, complete or block |

## Profiles are user-configured

Hermes setups vary widely. Before fanning out, discover available profiles:
- `hermes profile list` — prints the table of profiles
- `kanban_list(assignee="<name>")` — sanity-check a single name
- Just ask the user

The dispatcher silently fails to spawn unknown assignee names. A card assigned to a non-existent profile sits in `ready` forever.

---

## Orchestrator Playbook

### When to use the board vs delegate_task

Create Kanban tasks when: multiple specialists needed, work is long-running, user might interject, parallel subtasks, review expected, or audit trail matters. If none apply — use `delegate_task` or answer directly.

### Anti-temptation rules

- **Do not execute the work yourself.** Create a task for the right specialist.
- **Split multi-lane requests before creating cards.** One card per lane.
- **Run independent lanes in parallel.** Link only true data dependencies.
- **Never create dependent work as independent ready cards.** Use `parents=[...]`.
- **If no specialist fits, ask the user.** Don't invent profile names.
- **Decompose, route, and summarize — that's the whole job.**

### Decomposition playbook

1. **Understand the goal** — ask clarifying questions if ambiguous
2. **Sketch the task graph** — draft it out loud, show to user before creating
3. **Create tasks and link** — use actual profile names, pass `parents=[...]` for dependencies
4. **Complete your own task** — mark done with summary of what you created
5. **Report back** — tell the user what you created with actual profile names

### Task graph example

```python
t1 = kanban_create(
    title="research: Postgres cost vs current",
    assignee="<profile-A>",
    body="Compare estimated infrastructure costs...",
)[\"task_id\"]

t2 = kanban_create(
    title="synthesize migration recommendation",
    assignee="<profile-B>",
    body="Read findings from T1 and T2...",
    parents=[t1],
)[\"task_id\"]
```

### Common patterns

- **Fan-out + fan-in:** N research cards with no parents, one synthesis card with all as parents
- **Parallel implementation + validation:** implementer card + explorer card in parallel, reviewer gated on both
- **Pipeline with gates:** planner → implementer → reviewer, each with `parents=[previous]`
- **Same-profile queue:** N tasks assigned to same profile, no dependencies, serialized by dispatcher
- **Human-in-the-loop:** any task can `kanban_block()` to wait for input

### Goal-mode cards (persistent workers)

For open-ended cards where one turn rarely finishes: `goal_mode=True` wraps the worker in a goal loop. After each turn, a judge evaluates against acceptance criteria. Budget exhausted → card blocked for human review.

### Recovering stuck workers

1. **Reclaim** — abort running worker, reset to `ready`
2. **Reassign** — switch to different profile
3. **Change profile model** — edit profile config, then reclaim

---

## Worker Playbook

### Workspace handling

| Kind | What it is | How to work |
|------|-----------|-------------|
| `scratch` | Fresh tmp dir | Read/write freely; GC'd when archived |
| `dir:<path>` | Shared persistent directory | Other runs read what you write |
| `worktree` | Git worktree | Run `git worktree add` if `.git` doesn't exist |

### Good summary + metadata shapes

**Coding task:**
```python
kanban_complete(
    summary="shipped rate limiter — token bucket, 14 tests pass",
    metadata={
        \"changed_files\": [\"rate_limiter.py\", \"tests/test_rate_limiter.py\"],
        \"tests_run\": 14, \"tests_passed\": 14,
    },
)
```

**Review-required (block instead of complete):**
```python
kanban_comment(body=\"review-required handoff: ...\" + json.dumps({...}, indent=2))
kanban_block(reason=\"review-required: rate limiter shipped, needs eyes on fallback choice\")
```

**Research task:**
```python
kanban_complete(
    summary=\"3 libraries reviewed; vLLM wins on throughput\",
    metadata={\"recommendation\": \"vLLM\", \"sources_read\": 12},
)
```

### Claiming cards you created

Pass created card ids in `created_cards` on `kanban_complete`. The kernel verifies each id exists and was created by your profile. **Only list ids from successful `kanban_create` returns — never invent ids.**

### Block reasons that get answered fast

Bad: `"stuck"`. Good: one sentence naming the specific decision needed. Leave longer context as a comment.

### Heartbeats

Good: `"epoch 12/50, loss 0.31"`. Bad: `"still working"`. Every few minutes max; skip for tasks under ~2 minutes.

### Retry scenarios

If `kanban_show` returns `runs: [...]` with closed runs, you're a retry. Check prior `outcome`/`summary`/`error`:
- `timed_out` — chunk the work or shorten it
- `crashed` — OOM, reduce memory footprint
- `spawn_failed` — profile config issue, block and ask human
- `blocked` — prior attempt blocked, check unblock comment in thread

### Do NOT

- Call `delegate_task` as substitute for `kanban_create`
- Call `clarify` — you're headless, use `kanban_block` instead
- Modify files outside `$HERMES_KANBAN_WORKSPACE`
- Complete a task you didn't finish — block it instead
- Create follow-up tasks assigned to yourself — assign to the right specialist

---

## CLI Fallback

Every tool has a CLI equivalent:
- `kanban_show` ↔ `hermes kanban show <id> --json`
- `kanban_complete` ↔ `hermes kanban complete <id> --summary "..." --metadata '{...}'`
- `kanban_block` ↔ `hermes kanban block <id> "reason"`
- `kanban_create` ↔ `hermes kanban create "title" --assignee <profile> [--parent <id>]`

Use tools from inside an agent; the CLI exists for the human at the terminal.

## Common Pitfalls

- **Inventing profile names that don't exist.** Dispatcher silently drops unknown assignees.
- **Bundling independent lanes into one card.** Create separate cards for independent outcomes.
- **Over-linking because of wording.** "Finally check X" may still be parallel with implementation.
- **Forgetting dependency links.** Use parent links; don't create all tasks as independent ready cards.
- **Task state can change between dispatch and startup.** Always `kanban_show` first.
- **Workspace may have stale artifacts.** Read the comment thread for retry context.
- **Don't rely on CLI when tools are available.** `hermes kanban` fails in containerized backends.
